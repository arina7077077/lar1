<?php

namespace Spatie\Ignition\Contracts;

interface ProvidesSolution
{
    public function getSolution(): Solution;
}
